
#ifndef _INCLUDE_SIGNATURE_ENTRY_
#define _INCLUDE_SIGNATURE_ENTRY_

enum SignatureEntryType
{
	SpecificByte,
	AnyByteOrNothing,
	AnyByte
};

#endif